document.addEventListener('DOMContentLoaded', function(){
    let width = innerWidth;
    let bol = false;
    let mainCon = document.querySelector('#mainContainer');
    let menu =  document.querySelector('#menu');
    let src = document.querySelector('#src');
    let modal = document.querySelector('#loginModal');
    let loginBox = document.querySelector('#loginBox');
    let idBox =  document.querySelector('#idBox');
    let pwBox = document.querySelector('#pwBox');
    let id =  document.querySelector('#id');
    let pw = document.querySelector('#pw');
    let id2 =  document.querySelector('#id2');
    let pw2 = document.querySelector('#pw2');
    let name =  document.querySelector('#name');
    let exit = document.querySelector('#exit');
    let exit2 = document.querySelector('#exit2');
    let signUp = document.querySelector('#signUp');
    let loginForm = document.querySelector('#loginForm');
    let loginBtn = document.querySelector('#loginBtn');
    let signForm = document.querySelector('#signForm');
    let sign = document.querySelector('#sign');
    let log = document.querySelector('#log');
    mainCon.style.left = (Math.max(1200, width) - Math.min(1200, width)) / 2 + 'px';
    menu.addEventListener('click', function(){
        if (bol) {
            src.style.display = "none";
            bol = false;
        } else {
            src.style.display = "block";
            bol = true;
        }
    });
    src.addEventListener('click', function(e){
        let id = e.target;
        if (id.innerText == '로그인') {
            modal.style.display = 'block';
            loginBox.style.display = 'flex';
        }
    });
    idBox.addEventListener('mouseover', function(){
        id.style.backgroundColor = "rgb(238, 237, 175)";
    });
    pwBox.addEventListener('mouseover', function(){
        pw.style.backgroundColor = "rgb(238, 237, 175)";
    });
    idBox.addEventListener('mouseout', function(){
        id.style.backgroundColor = "rgb(125, 198, 224)";
    });
    pwBox.addEventListener('mouseout', function(){
        pw.style.backgroundColor = "rgb(125, 198, 224)";
    });
    document.addEventListener('keydown', function(e){
        if (e.keyCode == 27) {
            modal.style.display = 'none';
            loginBox.style.display = 'none';
            loginForm.style.display = 'block';
            signForm.style.display = 'none';
        }
    });
    exit.addEventListener('click', function(){
        modal.style.display = 'none';
        loginBox.style.display = 'none';
    });
    exit2.addEventListener('click', function(){
        modal.style.display = 'none';
        loginBox.style.display = 'none';
        loginForm.style.display = 'block';
        signForm.style.display = 'none';
    });
    signUp.addEventListener('click', function(){
        loginForm.style.display = 'none';
        signForm.style.display = 'block';
    });
    sign.addEventListener('click', function(e){
        e.preventDefault();
        localStorage.setItem('id', id2.value);
        localStorage.setItem('pw', pw2.value);
        localStorage.setItem('name', name.value);
        modal.style.display = 'none';
        loginBox.style.display = 'none';
        loginForm.style.display = 'block';
        signForm.style.display = 'none';
    });
    loginBtn.addEventListener('click', function(e){
        e.preventDefault();
        if (id.value != '' && pw.value != '') {
            if (id.value == localStorage.getItem('id') && pw.value == localStorage.getItem('pw')) {
            alert(localStorage.getItem('name') + '님 환영합니다.');
            modal.style.display = 'none';
            loginBox.style.display = 'none';
            loginForm.style.display = 'block';
            signForm.style.display = 'none';
            log.textContent = localStorage.getItem('name') + '(user)';
            } else {
            alert('로그인 실패');
            }
        }
    });
})