-- 시노님 테스트를 위한 사용자 계정 생성 - SYS 로 접속해야함
CREATE USER hrtest IDENTIFIED BY 1234;
GRANT CREATE SESSION TO hrtest;


-- SYS계정으로 접속해 공개 동의어 생성
-- 공개 동의어(SYNONYM)는 오라클의 모든 사용자가 접근 가능해야 하므로 DBA 권한을 가진
-- SYS, SYSTEM 계정으로 생성할 수 있음
CREATE OR REPLACE PUBLIC SYNONYM p_m FOR hr.members;

DROP PUBLIC SYNONYM p_m;


--########################################################################
-- 사용자 계정과 권한 관리

-- sys 계정으로 접속
-- 테스트용 사용자 계정 생성
CREATE USER test1 IDENTIFIED BY 12345678;

-- 사용자에게 시스템 권한 부여
GRANT CREATE SESSION TO test1;

-- test1에게 테이블을 생성할 수 있는 권한 부여
GRANT CREATE TABLE TO test1;

-- SYS 계정에서 test1 계정에 테이블 스페이스 접근 권한을 부여
ALTER USER test1 QUOTA UNLIMITED ON USERS;
ALTER USER test2 QUOTA UNLIMITED ON USERS;


-- sys 계정에서 작업 
-- 특정 사용자에게 시스템 권한 부여
GRANT CREATE SESSION, CREATE TABLE, CREATE VIEW TO test1;

GRANT CREATE SESSION, CREATE TABLE, CREATE VIEW, CREATE USER
TO test1 WITH ADMIN OPTION;

-- SYS 계정으로 접속해 작업
-- 롤을 이용해 TEST2에게 권한 부여
GRANT CONNECT, RESOURCE TO test2;

-- sys 계정으로 접속
-- 사용자 정의 롤 만들기
CREATE ROLE test2_role;
GRANT CREATE SESSION, CREATE TABLE TO test2_role;

GRANT test2_role TO test2;
DROP ROLE test2_role;

REVOKE test2_role FROM test2;
REVOKE RESOURCE FROM test2;












