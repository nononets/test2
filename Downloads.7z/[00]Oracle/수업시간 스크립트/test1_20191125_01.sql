-- test1으로 접속해 작업
-- member 테이블 생성
CREATE TABLE member(no NUMBER, name VARCHAR2(5 CHAR));

INSERT INTO member VALUES(1001, '오라클');
INSERT INTO member VALUES(1002, '어머나');
INSERT INTO member VALUES(1003, '홍길동');

SELECT * FROM member;

-- TEST1 계정으로 접속해 작업
-- TEST1 계정에서 TEST2 사용자를 생성하고 권한 부여
CREATE USER test2 IDENTIFIED BY 12345678;

GRANT CREATE SESSION, CREATE TABLE to test2;

SELECT * FROM member;

-- test1 계정으로 접속
-- test2 계정에게 test1의 member 테이블에 접근할 수 있는 권한부여
GRANT SELECT, INSERT, UPDATE, DELETE ON member TO test2;


-- TEST1 계정으로 접속해서 HR 계정으로 부터 받은 권을을 설절ㅇ
GRANT SELECT, INSERT, UPDATE, DELETE ON hr.members TO test2;


-- test1 계정에서 hr 계정으로부터 부여받은 member 테이블을 조회
SELECT * FROM hr.member;

-- 현재 사용자가 다른 사용자로부터 부여받은 권한 조회- user_tab_privs_recd;
SELECT * FROM user_tab_privs_recd;

-- 현재 사용자가 다른 사용자에게 부여한 권한 조회
SELECT * FROM user_tab_privs_made;







