-- TEST2 계정으로 접속해 테이블 생성
CREATE TABLE mem00(
    no NUMBER,
    name VARCHAR2(5 CHAR)
);
INSERT INTO mem00 VALUES(1010, '연개소문');

SELECT * FROM test1.member;

SELECT * FROM hr.members;


-- test2 계정으로 접속해 롤이 제대로 부여되었는지 확인
SELECT * FROM user_role_privs;


-- 사용자 정의 롤 만들기
CREATE ROLE test2_role;
GRANT CREATE SESSION, CREATE TABLE TO test2_role;




