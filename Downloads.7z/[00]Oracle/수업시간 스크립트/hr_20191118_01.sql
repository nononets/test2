-- employees 테이블에 데이터 추가하기
INSERT INTO employees(employee_id, first_name, last_name, email,
    hire_date, job_id, salary, manager_id, department_id)
VALUES(207, 'jin', 'won', 'midastop@naver.com',
    '15-08-21', 'PU_MAN', 10000, 108, 100);
    
-- 데이터베이스에 반영
commit;
    
SELECT * FROM employees WHERE employee_id = 207;

-- 데이터 수정하기
-- UPDATE 수정할 테이블 이름 SET 수정할 컬럼1 = 데이터1, 컬럼2 = 데이터2, ... WHERE 조건
UPDATE employees SET first_name = 'JINI', hire_date = '17-05-03'
WHERE employee_id = 207;
rollback;
commit;

SELECT employee_id, first_name, last_name, hire_date FROM employees;


-- 데이터 삭제하기
DELETE FROM employees WHERE employee_id = 207;
SELECT * FROM employees WHERE employee_id = 207;
commit;


-- 테이블 생성
CREATE TABLE member(
    no NUMBER,
    id VARCHAR2(15),
    password VARCHAR2(15),
    name VARCHAR2(5 CHAR),
    gender VARCHAR2(2 CHAR),
    email VARCHAR2(20),
    phone VARCHAR2(13)
);

-- 테이블의 컬럼의 데이터 타입 확인
DESC member;

-- member 테이블에 데이터 추가하기
INSERT INTO member
VALUES(1, 'oracle', 'oracle1234', '홍길동', '남성', 'oracle@naver.com', '010-1234-5678');
INSERT INTO member
VALUES(2, 'javagirl', 'javamania', '김하나', '여성', 'java@oracle.com', '010-4321-9876');
INSERT INTO member
VALUES(3, 'database', 'mysql', '최고집', '남성', 'database@gmail.com', '010-1111-7777');
commit;
SELECT * FROM member;


-- 실습 스키마 설치
@d:\EMP_EXAMPLE.sql

SELECT * FROM emp;

@d:\star.sql

@d:\union_set.sql

@d:\example_join.sql

@d:\subquery.sql




--##############################################################
-- 데이터 조회하기
--##############################################################
-- emp(사원) 테이블의 모든 데이터 조회
SELECT * FROM emp;
SELECT * FROM employees;
SELECT * FROM dept;

-- 사원 테이블에서 특정만 조회
SELECT empno, ename, sal FROM emp;
SELECT ename, sal, job, empno FROM emp;

-- 조회하는 컬럼에 별칭을 부여해서 조회
SELECT empno AS 사번, ename 이름, hiredate 입사일, deptno 부서_번호 FROM emp;


-- 산술 연산자를 활용한 데이터 조회하기
SELECT empno 사번, ename 이름, sal 급여, sal * 12 연봉 FROM emp;

-- 문자 연산자를 활용한 데이터 조회
-- 문자 연산자(||) - 문자열과 문자열을 연결
SELECT ename 이름, '은 ', job 직급, '이고 월급은 ', sal 월급 FROM emp;
SELECT ename || '은 ' || job || '이고 월급은' || sal FROM emp;


-- 조건에 맞는 데이터 조회
-- 조건절 비교연산자를 이용한 데이터 조회
-- 같다(=), 같지않다 (<>, !=), 크다 (>)
-- 크기를 비교할 수 있는 수치 데이터를 대상으로 함
-- 사원 테이블에서 사원 번호가 1004인 사원의 정보를 조회
SELECT empno 사번, ename 이름, job 직급 FROM emp
WHERE empno = 1204;

-- 급여가 450만원 이하인 사원 정보를 조회 단, 사번, 이름, 직급, 월급을 조회
SELECT empno 사번, ename 이름, job 직급, sal 월급 FROM emp
WHERE sal <= 450;

-- 사원 테이블에서 영업부 소속이 아닌 사원을 조회 단, 사번, 부서번호, 이름, 직급
-- 영업부는 부서 번호가 30  -> emp 테이블에서 부서 번호가 30이 아닌 사원을 조회
SELECT * FROM dept;
SELECT empno 사버, deptno 부서번호, ename 이름, job 직급 FROM emp
WHERE deptno <> 30;
SELECT empno 사버, deptno 부서번호, ename 이름, job 직급 FROM emp
WHERE deptno != 30;


-- 비교 연산자를 이용한 날짜 데이터 조회
-- 사원 테이블에서 2007년 3월 이전에 입사한 사원 조회 단, 사버, 이름, 입사일, 직급
SELECT empno, ename, hiredate, job FROM emp
WHERE hiredate < '2007-03-01';
SELECT empno, ename, hiredate, job FROM emp
WHERE hiredate < '2007/03/01';
SELECT empno, ename, hiredate, job FROM emp
WHERE hiredate < TO_DATE('2007-03-01');


-- 조건에 문자 데이터를 비교해서 조회
-- 이름이 홍길동인 사원의 정보 조회 - 이름이 일치할 경우
SELECT * FROM emp
WHERE ename = '홍길동';

-- 이름이 김으로 시작하면
SELECT * FROM emp
WHERE ename LIKE '김%';

-- 이름의 두 번째 자가 사인
SELECT * FROM emp
WHERE ename LIKE '_사%';

-- 이름이 김으로 시작하지 않으면
SELECT * FROM emp
WHERE ename NOT LIKE '김%';


-- 여러 조건을 만족하는 조회 - 특정 범위, 다중 조건 - 논리연산자 사용
-- 성씨가 김씨이고 급여가 350만원 이상인 사원 조회
SELECT * FROM emp
WHERE ename LIKE '김%'
    AND sal >= 350;
    
-- 급여가 400만 ~ 450만 사원의 정보
SELECT * FROM emp
WHERE sal >= 400
    AND sal <= 490; 
    
SELECT * FROM emp
WHERE sal BETWEEN 400 AND 490;


-- 경리부(10) 소속 이거나 전산부(40)인 사원 조회
SELECT * FROM emp
WHERE deptno = 10 
    OR deptno = 40;

SELECT * FROM emp
WHERE deptno IN(10, 40);

SELECT * FROM emp
WHERE (deptno = 10 
    OR deptno = 40)
    AND sal >= 450;    









