-- 2019년 11월 19일 화요일

-- 차집합(MINUS)
-- 싱글활동만하는 연예인 조회
SELECT * FROM single_star   -- A집합
MINUS
SELECT * FROM group_star;   -- B집합

-- 교수 테이블에서 전임강사를 제외한 교수 조회하기
SELECT name, position FROM professor
MINUS
SELECT name, position FROM professor
WHERE position = '전임강사';


--#############################################################################
-- 오라클 기본함수
--#############################################################################
-- 더미 테이블 : DUAL
SELECT ROUND(30.123, 1) FROM dual;

-- 숫자 함수
-- 숫자 데이터를 입력으로 받아서 함수 내부에서 처리한 후 결과를 숫자로 반환
-- 절대값 구하는 함수
SELECT ABS(-11) FROM dual;

-- 입력값이 양수인지 음수인지를 판단하는 함수
SELECT SIGN(-7) 음수, SIGN(0) "0", SIGN(7) 양수 FROM dual;

-- 입력 값과 같거나 큰 가장 작은 정수
SELECT CEIL(7.12345), CEIL(-7.12345), CEIL(7), CEIL(-7), CEIL(0.12345) FROM dual;


-- 입력 값과 같거나 작은 가장 큰 정수
SELECT FLOOR(7.12345), FLOOR(-7.12345), FLOOR(7), FLOOR(-7), FLOOR(0.12345) FROM dual;

-- 지정한 자리에서 반올림 해주는 함수
-- 두 번째 인수로 반올림할 자리수를 지정, 지정한 자리수 + 1 번째 소수점에서 반올림이 이루어진다.
SELECT ROUND(7.123456789), ROUND(7.123456789, 0), ROUND(7.56789) FROM dual;

SELECT ROUND(7.12345, 2), ROUND(7.34567, 2) FROM dual;

SELECT ROUND(77777.12345, -2) FROM dual;


-- 지정한 자리에서 수를 잘라내는 함수
-- TRUNC(n, i)
SELECT TRUNC(7.12345), TRUNC(7.12345, 0) FROM dual;

SELECT TRUNC(7.12345, 2), TRUNC(7.1234567, 5) FROM dual;


-- 나머지를 구해주는 함수
SELECT MOD(7, 0), MOD(7, 2), MOD(7, -2) FROM dual;


-- 제곱을 구해주는 함수
SELECT POWER(7, 0), POWER(7, 2) FROM dual;
SELECT POWER(7, 2.1), POWER(-7, 2.1) FROM dual;


--------------------------------------------------------------------------
-- 문자 함수 - CHAR, VARCHAR2
-- 대소문자 변화 함수
SELECT UPPER('Hello ORACLE'), LOWER('HELLO Oracle') FROM dual;

-- 문자열에서 공백을 기준으로 단어로 구분해 첫 번째 문자를 대문자로 변환하고 나머지는 소문자로 변환
-- 공백, 탭, 숫자, 영문자
SELECT INITCAP('orAcle dataBase express ediTion 11g rElease2') FROM dual;
SELECT INITCAP('orAcle:dataBase한expRess1ediTion\11g,rElease2') FROM dual;

-- 문자열에서 일부만 추출
SELECT SUBSTR('Oracle Database Express Edition', 8, 8) FROM dual;
SELECT SUBSTR('오라클 데이터베이스 익스프레스 에디션', 8, 8) FROM dual;

SELECT SUBSTRB('Oracle Database Express Edition', 8, 8) FROM dual;
SELECT SUBSTRB('오라클 데이터베이스 익스프레스 에디션', 8, 8) FROM dual;

-- 문자열에서 일부만 지정한 문자열로 치환하는 함수
SELECT REPLACE('Oracle is difficult', 'difficult', 'easy') FROM dual; 

SELECT * FROM professor;
SELECT name, position, REPLACE(position, '전임', '시간') FROM professor;


-- 끝에 있는 문자열을 제거하는 함수
-- TRIM, LTRIM, RTRIM
-- LTRIM(string[, set])   RTRIM(string[, set])
SELECT name, position, LTRIM(position, '전임') FROM professor;
SELECT dname, RTRIM(dname, '부') FROM dept;

-- 양쪽 끝에 있는 문자열을 제거
-- TRIM([LEADING | TRAILING | BOTH][trim_char][FROM] string) 
SELECT '"   Hello Oracle   "', TRIM(LEADING FROM '   Hello Oracle   ') FROM dual;
SELECT 'AAABBBCCCAAA', TRIM('A' FROM 'AAABBBCCCAAA') FROM dual;

SELECT '하하하' || '호호호' FROM dual;
SELECT CONCAT('하하하', '호호호') FROM dual;


-- 지정한 문자를 채워서 반환하는 함수
-- LPAD(string, n [, char]), RPAD(string, n [, char])
-- n이 원본 string의 길이보다 작으면 원본 string을 길이 n만큼 반환한다.
SELECT 'ABCDEF', LPAD('ABCDEF', 2), LPAD('ABCDEF', 15, 'ORACLE') FROM dual;
SELECT 'ABCDEF', LPAD('ABCDEF', 15), LPAD('ABCDEF', 15, 'ORACLE') FROM dual;
SELECT 'ABCDEF', LPAD('ABCDEF', 13), LPAD('ABCDEF', 15, '하하하오라클호호호') FROM dual;

SELECT LPAD('Title', 15, '#'), RPAD('Title', 15, '#') FROM dual;


-- 문자열의 길이를 반환하는 함수 XE
SELECT LENGTH('오라클') "CHAR", LENGTHB('오라클') "BYTE" FROM dual;
SELECT LENGTH('oracle') "CHAR", LENGTHB('oracle') "BYTE" FROM dual;

SELECT * FROM nls_database_parameters;

-- 아스키 코드 값을 반환하는 함수
SELECT 'A', ASCII('A'), 'a', ASCII('a') FROM dual;


-- 문자의 위치를 반환하는 함수
-- SELECT INSTR(string, search, position)

SELECT 'ABCD ABCABC ABC AAA', INSTR('ABCD ABCABC ABC AAA', 'BC') FROM dual;

SELECT 'ABCD ABCABC ABC AAA', INSTR('ABCD ABCABC ABC AAA', 'BC', 3) FROM dual;

SELECT 'ABCD ABCABC ABC AAA', INSTR('ABCD ABCABC ABC AAA', 'A', 3, 3) FROM dual;


-----------------------------------------------------------------------------------
--- 날짜 함수
SELECT * FROM nls_database_parameters;
SELECT SYSDATE, CURRENT_DATE FROM dual;

SELECT * FROM emp;


-- 현재 접속한 세션 변경
ALTER SESSION SET TIME_ZONE = '0:0';
ALTER SESSION SET NLS_DATE_FORMAT='YYYY-MM-DD HH24:MI:SS';
SELECT * FROM nls_database_parameters;
-- NLS_CHARACTERSET = KO16MSWIN949
-- NLS_CHARACTERSET = 

SELECT SYSDATE, CURRENT_DATE FROM dual;
SELECT SYSTIMESTAMP, CURRENT_TIMESTAMP FROM dual;

-- 시간 데이터는 숫자 함수에서 사용한 잘림 TRANC, 반올림 ROUND
SELECT ROUND(SYSDATE, 'CC') CENTURY, 
      	ROUND(SYSDATE, 'YYYY') YEAR,
      	ROUND(SYSDATE, 'Q') QUARTER,
      	ROUND(SYSDATE, 'MONTH') MONTH,
      	ROUND(SYSDATE, 'DAY') WEEK,
      	ROUND(SYSDATE, 'DD') DAY,
      	ROUND(SYSDATE, 'HH24') H,
      	ROUND(SYSDATE, 'MI') M
	FROM dual;

SELECT TRUNC(SYSDATE, 'CC') CENTURY, 
      	TRUNC(SYSDATE, 'YYYY') YEAR,
      	TRUNC(SYSDATE, 'Q') QUARTER,
      	TRUNC(SYSDATE, 'MONTH') MONTH,
      	TRUNC(SYSDATE, 'DAY') WEEK,
      	TRUNC(SYSDATE, 'DD') DAY,
      	TRUNC(SYSDATE, 'HH24') H,
      	TRUNC(SYSDATE, 'MI') M
	FROM dual;
SELECT * FROM emp;




-- 현재 접속한 세션을 변경하기 전의 NLS_CHARACTERSET = KO16MSWIN949
-- 문자열의 길이를 반환하는 함수
SELECT LENGTH('오라클') "CHAR", LENGTHB('오라클') "BYTE" FROM dual;
SELECT LENGTH('oracle') "CHAR", LENGTHB('oracle') "BYTE" FROM dual;


-- 현재 접속한 세션의 NLS_CHARACTERSET = AL32UTF8 로 변경
ALTER SESSION SET NLS_CHARACTERSET='AL32UTF8';
SELECT * FROM nls_database_parameters;
SELECT * FROM NLS_SESSION_PARAMETERS;


