--####################################################
-- 시스템의 문자셋 변경하기
--#####################################################
-- 아래의 props$ 는 시스템 테이블로써 sys 스키마에 있기 때문에 반드시 SYS 계정으로 접속해야 함

-- 시스템 문자셋 조회
SELECT * FROM props$ 
WHERE name = 'NLS_CHARACTERSET';

-- 오라클의 한글 문제셋 체계
-- KO16MSWIN949 : 조합형 한글 - 완성형을 포함해 11172자(유니코드 문자)로 한글을 2Byte로 취급
-- AL32UTF8 : 유니코드 문자 11172자로 한글을 3Byte로 취급
-- 가 ~ 힣

-- 문자셋을 AL32UTF8로 변경하는 쿼리
UPDATE props$ SET value$ = 'AL32UTF8'
WHERE name = 'NLS_CHARACTERSET';
commit;

-- 문자셋을 KO16MSWIN949로 변경하는 쿼리
UPDATE props$ SET value$ = 'KO16MSWIN949'
WHERE name = 'NLS_CHARACTERSET';
commit;

-- 아래 쿼리로 조회하면 문자셋이 KO16MSWIN949 에서 AL32UTF8 변경되었지만
SELECT * FROM nls_database_parameters;

-- 실제 HR 계정에서 다음과 같이 조회해 보면 한글을 아직도 2Byte로 취급한다.
-- 이는 오라클 서버가 시작될 때 이전의 설정을 그대로 기억하고 있기 때문으로
-- 오라클 서버를 종료 후 다시 시작하면 3Byte로 인식할 것이다.
-- 윈도우 시스템을 다시 시작하지 않고 오라클 서버를 손쉽게 다시 시작하려면 작업 관리자를 실행해
-- 서비스 탭에서 OracleServiceORCL, OracleOraDb11g_home1TNSListener  두 프로세스를
-- 정지했다가 다시 시작해 주면 된다. 간혹 보안 문제로 작업관리자에서 액세스가 거부되는 경우가
-- 있는데 있데는 윈도우 시스템의 서비스 관리자를 실행해 위의 두 프로세스를 다시 시작해 주면 된다.

-- 그리고 HR계정에서 아래를 테스트하면 한글은 3Byte로 표시된다.
SELECT LENGTH('오라클') "CHAR", LENGTHB('오라클') "BYTE" FROM dual;
SELECT LENGTH('oracle') "CHAR", LENGTHB('oracle') "BYTE" FROM dual;









