-- 문자셋 오류에 대한 처리 - 아래 오류는 문자셋이 중복설정되어 발생한다.
-- ORA-06552: PL/SQL: Compilation unit analysis terminated
-- ORA-06553: PLS-553: character set name is not recognized

-- 먼저 sys 계정으로 접속한 후에 아래 명령으로 문자셋 중복 설정을 조회
SELECT DISTINCT(NLS_CHARSET_NAME(CHARSETID)) CHARACTERSET,
    DECODE(TYPE#, 1, DECODE(CHARSETFORM, 1, 'VARCHAR2', 2, 'NVARCHAR2','UNKOWN'),
            9, DECODE(CHARSETFORM, 1, 'VARCHAR', 2, 'NCHAR VARYING', 'UNKOWN'),
            96, DECODE(CHARSETFORM, 1, 'CHAR', 2, 'NCHAR', 'UNKOWN'),
            112, DECODE(CHARSETFORM, 1, 'CLOB', 2, 'NCLOB', 'UNKOWN')) TYPES_USED_IN
FROM SYS.COL$ 
WHERE CHARSETFORM IN (1,2) AND TYPE# IN (1, 9, 96, 112);

-- parallel_server parameter 가 false 거나 아예 세팅되어있지 않은지 확인한다
show parameter parallel_server;

-- 다음 명령을 차례로 실행
-- 접속중인 세션, 진행중인 트랜잭션 종료
SHUTDOWN IMMEDIATE;

-- 마운트 단계까지 오라클 시작
START MOUNT;

-- 세션 제한 모드 활성화(문자셋 변경과정에서 발생하는 오류를 막기위해)
ALTER SYSTEM ENABLE RESTRICTED SESSION;

-- 문자셋 변경 중 오류를 막기 위해 QueueMonitorCoordinator 비활성화
ALTER SYSTEM SET AQ_TM_PROCESSES = 0; 

-- job queue안의 job을 수행하지 않도록 설정 (문자셋 변경 중 오류를 막기 위해)
ALTER SYSTEM SET JOB_QUEUE_PROCESSES = 0;   

-- 데이터베이스 오픈
ALTER DATABASE OPEN;

-- SELECT 쿼리 실행 시 결과값과 컬럼명을 같이 보여주라는 의미
COL VALUE NEW_VALUE CHARSET

-- NLS_CHARACTERSET의 문자셋 확인
SELECT VALUE FROM NLS_DATABASE_PARAMETERS WHERE PARAMETER='NLS_CHARACTERSET';   

-- NLS_NCHAR_CHARACTERSET 확인
COL VALUE NEW_VALUE NCHARSET
SELECT VALUE FROM NLS_DATABASE_PARAMETERS WHERE PARAMETER = 'NLS_NCHAR_CHARACTERSET';

-- 문자셋 변경시, 데이터 손상 방지를 위한 검사를 건너뛰고 변경(INTERNAL_USE가 검사를 건너뛰라는 의미)
ALTER DATABASE CHARACTER SET INTERNAL_USE & CHARSET;
ALTER DATABASE NATIONAL CHARACTER SET INTERNAL_USE & NCHARSET; 

-- 접속중인 세션, 진행중인 트랜잭션 종료
SHUTDOWN IMMEDIATE;

-- 시작
STARTUP;

-- 종료
SHUTDOWN IMMEDIATE;

-- 시작
STARTUP;


