-- 2019년 11월 20일 수요일
-- 날짜 함수
SELECT * FROM nls_database_parameters;
SELECT * FROM nls_session_parameters;
SELECT SYSDATE, CURRENT_DATE FROM dual;

-- 두 날짜 사이의 개월 수를 구하는 함수
SELECT ename 이름, SYSDATE today, hiredate 입사일, ROUND(MONTHS_BETWEEN(SYSDATE, hiredate)) months FROM emp;

-- 날짜에 개월 수를 더해주는 함수
SELECT SYSDATE today, ADD_MONTHS(SYSDATE, 12) FROM dual;
SELECT SYSDATE today, ADD_MONTHS(SYSDATE, -3) FROM dual;

-- 지정한 날짜에서 지정한 요일이 가장 가까운 날짜를 구해주는 함수   1(일) ~ 7(토)
SELECT SYSDATE today, NEXT_DAY(SYSDATE, 2) "다음 월요일" FROM dual;
SELECT SYSDATE today, NEXT_DAY(SYSDATE, 7) "다음 월요일" FROM dual;

-- 지정한 달의 마지막 날짜를 구하는 함수   '2019-11-20'
SELECT SYSDATE today, LAST_DAY(SYSDATE) lastday FROM dual;

SELECT SYSDATE today, LAST_DAY('2020-02-03') lastday FROM dual;



--#######################################################################
-- 변환 함수
-- 문자형 데이터로 변환해 주는 함수 :  TO_CHAR()
-- 2019년 10월 20일, 985,623

-- 날짜 데이터를 문자로 변환
SELECT SYSDATE, TO_CHAR(SYSDATE) FROM dual;
SELECT SYSDATE, TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS DAY') FROM dual;
SELECT SYSDATE, TO_CHAR(SYSDATE, 'YYYY"년" MM"월" DD"일" HH24"시" MI"분" SS"초" DAY') FROM dual;

-- 숫자 데이터를 문자로 변환
SELECT 1234567, TO_CHAR(12345678, 'L99,999,999') FROM dual;
SELECT 1234567, TO_CHAR(12345.678, '$999,990.00') FROM dual;


-----------------------------------------------------------------------------
-- 날짜형 데이터로 변환해 주는 함수 : TO_DATE(arg, fmt)
SELECT TO_DATE('2015-09-09 13:05:23', 'YYYY-MM-DD HH24:MI:SS') FROM dual;

SELECT * FROM emp
WHERE hiredate > TO_DATE(20100303);

SELECT * FROM emp
WHERE hiredate > TO_DATE('2010-03-03');


------------------------------------------------------------------------
-- 숫자형 데이터로 변환해 주는 함수 : TO_NUMBER(arg, fmt)
SELECT '5700' + '3000' FROM dual;

SELECT TO_NUMBER('$5,700', '$999,999') + TO_NUMBER('$3,000', '$999,999') FROM dual;


---------------------------------------------------------------------
-- NULL 데이터를 다른 값으로 변환해 주는 함수 : NVL(arg, rep)
SELECT * FROM emp;

SELECT empno, ename, job, sal, sal + NVL(comm, 0)"급여 합계" FROM emp
WHERE sal + NVL(comm, 0) > 300;

-- NVL2(arg, rep1, rep2)
SELECT empno, ename, job, sal, NVL2(comm, sal + comm, sal)"급여 합계" FROM emp
WHERE NVL2(comm, sal+ comm, sal) > 300;


--##########################################################################
-- 조건 함수  : 프로그래밍에서 if~else, switch 문과 비스한 기능을 제공하는 함수
-- DECODE, CASE
-- DECODE(expression, 조건1, 결과1, 조건2, 결과2, .... [, default])
SELECT * FROM department;
-- 학과번호에 해당하는 학과명을 출력
SELECT name 이름, pay 급여, deptno 학과코드, 
    DECODE(deptno, 
        101, '컴퓨터공학과', 
        102, '멀티미디어공학과',
        103, '소프트웨어공학과',
        201, '전자공학과',
        202, '기계공학과',
        203, '화학공학과',
        301, '문헌정보학과') 학과명
FROM professor;


SELECT * FROM emp;


-- CASE 함수
-- 사원의 성별 조회
SELECT ename 이름, 
    DECODE(gender, 'F', '여성', 'M', '남성') 성별1,
    CASE gender WHEN 'F' THEN '여성'
        WHEN 'M' THEN '남성'
        ELSE ''    
    END 성별2
FROM emp;    


-- 사원의 연령대 조회  20대, 30대, 40대, 50대, ...
SELECT ename 이름, birthday 생일, 
    CASE WHEN ROUND((SYSDATE - birthday) / 365) >= 20 
        AND ROUND((SYSDATE - birthday) / 365) <= 29 
        THEN '20대'
        WHEN ROUND((SYSDATE - birthday) / 365) >= 30 
        AND ROUND((SYSDATE - birthday) / 365) <= 39 
        THEN '30대'
        WHEN ROUND((SYSDATE - birthday) / 365) >= 40 
        AND ROUND((SYSDATE - birthday) / 365) <= 49 
        THEN '40대'
        WHEN ROUND((SYSDATE - birthday) / 365) >= 50 
        AND ROUND((SYSDATE - birthday) / 365) <= 59 
        THEN '50대'
        ELSE '기타'
    END 연령대 FROM emp;



SELECT * FROM emp;

--###############################################################################
-- 그룹함수 -> 집계함수

-- 그룹함수는 죄회하는 대상을 그룹으로 묶어 집계를 해주는 함수
-- 그룹으로 묶어주는 GROUP BY 그룹의 결과는 특정 조건으로 제한하는 HAVING

-- 전체 사원 수 급여 총액 조회
SELECT 
    COUNT(gender) || '명', TO_CHAR(SUM(sal), 'L999,999' ) || '만원' "급여 총액" 
FROM emp;

-- 전체를 하나의 그룹으로 묶어서 조회
SELECT COUNT(DISTINCT job) FROM emp;

-- 전체가 아니라 부서별 그룹으로 묶어서 조회
SELECT deptno 부서, COUNT(*) 인원수 
FROM emp
GROUP BY deptno
ORDER BY deptno;

-- 급여 총액과 평균 
SELECT sum(sal) 급여총액, avg(sal) 평균급여 FROM emp;

-- 부서별 급여 총액과 평균 
SELECT deptno 부서코드, sum(sal) 급여총액, avg(sal) 평균급여 
FROM emp
GROUP BY deptno;

-- COUNT, SUM, AVG, MIN, MAX, 
SELECT SUM(comm) 커미션총액, ROUND(AVG(comm), 2), SUM(comm) / 25 FROM emp;


-- 부서별 급여 총액과 평균 
SELECT deptno 부서코드, sum(sal) 급여총액, avg(sal) 평균급여 
FROM emp
GROUP BY deptno;
SELECT * FROM dept;

-- 영업부의 직급별 직원의 급여 합계
SELECT job, SUM(sal), MIN(sal), MAX(sal) FROM emp
WHERE deptno = 30
GROUP BY job;

-- 부서별 급여합계, 평균급여, 부서번호, 부서명, 같이 출력
SELECT deptno 부서번호, 
    DECODE(deptno, 10, '경리부', 20, '인사부', 30, '영업부', 40, '전산부') 부서명, 
    SUM(sal) 급여합계, AVG(sal) FROM emp

GROUP BY deptno
ORDER BY deptno;


-- 남자 직원이 3명 미만인 부서를 조회, 부서번호, 남자 직원수를 출력
SELECT deptno 부서번호, COUNT(gender) || '명' 남자직원수
FROM emp
WHERE gender = 'M'
GROUP BY deptno
HAVING COUNT(gender) < 3
ORDER BY deptno;

-- 직급 별 인원수, 급여 합계를 구해 출력. 단, 직급 순으로 정렬하시오.
-- 사원 < 대리 < 과장 < 차장 < 부장 < 이사 < 사장
-- 1 <  2 <  3 <  4 <  5 <  6 <  7
SELECT job, COUNT(job), SUM(sal), ROUND(AVG(sal), 1) FROM emp
WHERE job NOT LIKE '%사장%'--<> '사장'
GROUP BY job
ORDER BY DECODE(job, '사원', 1, '대리', 2, '과장', 3,
                '차장', 4, '부장', 5, '이사', 6, '사장', 7);



--##############################################################################
-- 조인(JOIN) : 두 개 이상의 테이블을 연결해서 데이터를 조회하는 것
-- 부서번호에 해당하는 부서명을 출력
SELECT deptno 부서번호, 
    DECODE(deptno, 10, '경리부', 20, '인사부', 30, '영업부', 40, '전산부') 부서명, 
    SUM(sal) 급여합계, AVG(sal) FROM emp
GROUP BY deptno;

-- 사원의 정보를 출력, 부서명을 같이 출력 -> 조인 (emp, dept)
SELECT ename, deptno FROM emp;
SELECT * FROM dept;

-- WHERE 절에 일반 조건와 조인 조건을 같이 제시한다.
SELECT e.ename, e.job, d.* FROM emp e, dept d
WHERE e.deptno = d.deptno;  






