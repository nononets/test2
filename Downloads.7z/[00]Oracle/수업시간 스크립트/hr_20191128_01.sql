-- 2019년 11월 28일 목요일
-- PL/SQL

-- 이름이 지정되지 않는 PL/SQL  -> 익명블록(Anonymous Block)
-- 이름이 지정된 PL/SQL -> 서브프로그램(Sub Program) -> 프로시저, 함수, 트리커, 패키지

-- PL/SQL 익명블록의 구조
/*
DECLARE

BEGIN

EXCEPTION WHEN THEN

END;
*/

DECLARE
    -- PL/SQL 한 줄 주석 : begin(실행부)에서 사용할 변수 선언
    str VARCHAR2(15) := 'HELLO ';
BEGIN -- 실행부
    str := str || 'PL/SQL';
    
    DBMS_OUTPUT.PUT_LINE('  ' || str);
    DBMS_OUTPUT.PUT_LINE('');
END; -- 실행부 종료
/


-- PL/SQL 변수
p_studno NUMBER(4) := '홍길동';
p_name VARCHAR2(10);
p_grade NUMBER := 4;

-- 상수선언 : 선언과 동시에 초기화가 되어야 함
p_base CONSTANT INTEGER := 20;  -- O
p_base CONSTANT BOOLEAN;   -- X


-- 단순변수 -> 스칼라변수, 참조변수
-- 스칼라 타입  : 숫자, 문자, 날짜 데이터
-- 참조타입 : 테이블의 컬럼 참조, 테이블의 행 참조

CREATE TABLE ref_var(
    no NUMBER,
    name VARCHAR2(10),
    age NUMBER(3, 0)
);
INSERT INTO ref_var VALUES(1, '홍길동', 37);
INSERT INTO ref_var VALUES(2, '임꺽정', 100);
INSERT INTO ref_var VALUES(3, '장길산', 1);
COMMIT;

-- PL/SQL 익명블록
DECLARE 
    p_no NUMBER := 0;
    p_name VARCHAR2(10);
    p_age NUMBER(3, 0);
    
BEGIN
    SELECT no, name, age
        INTO p_no, p_name, p_age
    FROM ref_var
    WHERE no = 1;
    
    DBMS_OUTPUT.PUT_LINE('  no  이름  나이');
    DBMS_OUTPUT.PUT_LINE('  ' || p_no || '  ' || p_name || '    ' || p_age);
END;
/


-- 참조변수
-- 테이블의 컬럼을 참조 : %TYPE
-- 테이블의 행을 참조 : %ROWTYPE

DECLARE
    p_no ref_var.no%TYPE;
    p_name ref_var.name%TYPE;
    p_age ref_var.age%TYPE;
    
BEGIN
    SELECT no, name, age
        INTO p_no, p_name, p_age
    FROM ref_var
    WHERE no = 2;
    
    DBMS_OUTPUT.PUT_LINE('  no  이름  나이');
    DBMS_OUTPUT.PUT_LINE('  ' || p_no   ||  '   ' || p_name || '    ' || p_age);
END;
/


-- 테이블의 행을 참조하는 참조타입 변수
DECLARE
    p_refvar ref_var%ROWTYPE;
    
BEGIN
    SELECT * INTO p_refvar
    FROM ref_var
    WHERE no = 3;
    
    DBMS_OUTPUT.PUT_LINE('  no  이름  나이');
    DBMS_OUTPUT.PUT_LINE('  ' || p_refvar.no 
            || '    ' || p_refvar.name || '  ' || p_refvar.age);
END;
/


-- 복합변수
-- 레코드 타입, 컬렉션 계열의 타입
-- 레코드 타입 변수
-- %TYPE으로 레코드 선언
DECLARE
    p_record ref_var%ROWTYPE;
    
BEGIN
    SELECT * INTO p_record
    FROM ref_var
    WHERE no = 1;
    
    DBMS_OUTPUT.PUT_LINE(p_record.no 
            || '   ' || p_record.name || ' ' || p_record.age);
END;
/

-- TYPE 키워드와 %TYPE 을 이용한 레코드 타입 선언
DECLARE
    TYPE REF_VAR_RECORD IS RECORD(
        no ref_var.no%TYPE,
        name ref_var.name%TYPE,
        age ref_var.age%TYPE
    );
    
    p_record REF_VAR_RECORD;
BEGIN
    SELECT no, name, age 
        INTO p_record
    FROM ref_var
    WHERE no = 2;
    
    DBMS_OUTPUT.PUT_LINE(p_record.no 
            || '   ' || p_record.name || '  ' || p_record.age);
    
    
END;
/


-- 레코드를 이용해 테이블에 데이터 추가/수정
DECLARE 
    p_record ref_var%ROWTYPE;
    
    TYPE REF_VAR_RECORD IS RECORD(
        no ref_var.no%TYPE,
        name ref_var.name%TYPE,
        age ref_var.age%TYPE
    );
    type_record REF_VAR_RECORD;
BEGIN
    p_record.no := 4;
    p_record.name := '이순신';
    p_record.age := 33;
    
    INSERT INTO ref_var VALUES p_record;
    
    type_record.no := 3;
    type_record.name := '강감찬';
    type_record.age := 55;
    
    -- UPDATE 
    UPDATE ref_var SET row = type_record
    WHERE no = type_record.no;
    COMMIT;
    
    -- ref_var 테이블에서 no가 4인 데이터 읽기
    SELECT * INTO p_record
    FROM ref_var WHERE no = 4;
    
    p_record.name := '김유신';
    p_record.age := 77;
    
    UPDATE ref_var SET name = p_record.name, age = p_record.age
    WHERE no = p_record.no;
    COMMIT;
    
END;
/

SELECT * FROM ref_var;



--- 제어문 -> 조건, 반복
-- 조건문
/*
1. 한 가지 조건 - 참인 경우만 처리하는 경우
IF 조건1 THEN
    조건1이 참인 경우 실행문
END IF;

2. 두 가지 조건 - 참과 거짓을 모두 처리하는 경우
IF 조건1 THEN
    조건1이 참인 경우 실행문
ELSE
    조건1이 거짓인 경우 실행문
END IF;

3. 두 가지 이상의 조건 
IF 조건1 THEN
    조건1이 참인 경우 실행문
ELSIF 조건2 THEN
    조건2가 참인 경우 실행문
...

END IF;
*/
-- EMP 테이블에서 이름과 성별을 조회해서 성별이 F 면 여성 거짓이면 남성 출력 
DECLARE 
    p_ename emp.ename%TYPE;
    p_gender emp.gender%TYPE;
BEGIN
    SELECT ename, gender
        INTO p_ename, p_gender
    FROM emp
    WHERE empno = '&사번입력';
    
    IF p_gender = 'F' THEN
        DBMS_OUTPUT.PUT_LINE(p_ename || ' 은 여성 입니다.');
    ELSE
        DBMS_OUTPUT.PUT_LINE(p_ename || ' 은 남성 입니다.');
    END IF;
END;
/


-- 여러 조건에 대한 처리
DECLARE
    p_name professor.name%TYPE;
    p_position professor.position%TYPE;
    p_deptno professor.deptno%TYPE;
    p_dname VARCHAR2(20, CHAR);

BEGIN
    SELECT name, position, deptno
        INTO p_name, p_position, p_deptno
    FROM professor
    WHERE name = '&교수명입력';
    
    IF p_deptno = 101 THEN
        p_dname := '컴퓨터공학과';
    ELSIF p_deptno = 102 THEN
        p_dname := '멀티미디어공학과';
    ELSIF p_deptno = 103 THEN
        p_dname := '소프트웨어공학과';
    ELSIF p_deptno = 201 THEN
        p_dname := '전자공학과';
    ELSIF p_deptno = 202 THEN
        p_dname := '기계공학과';
    ELSIF p_deptno = 203 THEN
        p_dname := '화학공학과';
    ELSIF p_deptno = 301 THEN
        p_dname := '문헌정보학과';    
    END IF;
    
    DBMS_OUTPUT.PUT_LINE(p_name || '    ' || p_position || '    ' || p_dname);
    
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('입력한 이름에 해당하는 교수가 존재하지 않습니다.');
        WHEN TOO_MANY_ROWS THEN
            DBMS_OUTPUT.PUT_LINE('입력한 이름의 교수가 한 명이 아닙니다.');
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('교수를 검색하는 중 오류 발생~~');
END;
/

SELECT * FROM department;
SELECT * FROM professor;

-- CASE 문 
/*
CASE 조건 
    WHEN 비교값1 THEN 처리 코드1
    WHEN 비교값2 THEN 처리 코드2
    WHEN 비교값2 THEN 처리 코드2
    [ELSE 기본처리]
END CASE;

CASE 
    WHEN 비교조건1 THEN 처리1
    WHEN 비교조건2 THEN 처리2
    ...
    [ELSE 기본처리]
END CASE;
*/

-- 
DECLARE 
    p_name professor.name%TYPE;
    p_position professor.position%TYPE;
    p_deptno professor.deptno%TYPE;
    p_dname VARCHAR2(20, CHAR);    

BEGIN 
    SELECT name, position, deptno
        INTO p_name, p_position, p_deptno
    FROM professor
    WHERE name = '&교수명입력';
    
    CASE p_deptno
        WHEN 101 THEN
            p_dname := '컴퓨터공학과';
        WHEN 102 THEN
            p_dname := '멀티미디어공학과';            
        WHEN 103 THEN
            p_dname := '소프트웨어공학과';
        WHEN 201 THEN
            p_dname := '전자공학과';            
        WHEN 202 THEN
            p_dname := '기계공학과';
        WHEN 203 THEN
            p_dname := '화학공학과';            
        WHEN 301 THEN
            p_dname := '문헌정보학과';
        ELSE NULL;
    END CASE;
    
    DBMS_OUTPUT.PUT_LINE('이름    직급  학과명');
    DBMS_OUTPUT.PUT_LINE(p_name || '    ' || p_position || '    ' || p_dname);
    
END;
/


--- 반복문
-- FOR LOOP 문
-- 구구단 7단
DECLARE 
    base NUMBER := 7;
BEGIN
    FOR i IN 1.. 9 LOOP
        DBMS_OUTPUT.PUT_LINE(base || ' x ' || i || ' = ' || base * i);
    END LOOP;
END;
/

-- LOOP 문
DECLARE 
    i NUMBER := 0;
BEGIN
    LOOP
        DBMS_OUTPUT.PUT_LINE('현재 값 : ' || i);
        i := i + 1;
        
        EXIT WHEN i>= 5;    
    END LOOP;
END;
/


-- WHILE LOOP 문
DECLARE 
    i NUMBER := 0;
BEGIN
    WHILE i <= 5  LOOP
        DBMS_OUTPUT.PUT_LINE('현재 값 : ' || i);
        i := i + 1;
        IF i > 4 THEN
            EXIT;
        END IF;        
        --EXIT WHEN i > 4
    END LOOP;
END;
/


-- 
DECLARE 
    count1 PLS_INTEGER;
    count2 PLS_INTEGER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('커서 상태 ' || 
        NVL(CASE SQL%FOUND
                WHEN TRUE THEN 'FOUND'
                WHEN FALSE THEN 'NOT FOUND'
            END, 'NULL'));
            
    SELECT COUNT(*) INTO count1 FROM emp;
    
    count2 := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('커서 상태 ' || 
        NVL(CASE SQL%FOUND
                WHEN TRUE THEN 'FOUND'
                WHEN FALSE THEN 'NOT FOUND'
            END, 'NULL'));
END;
/

/*
CURSOR 커서 이름 IS SLELECT 문;

OPEN 커서

FETCH 커서이름 INTO 변수1, 변수2, ...

CLOSE 커서
*/
SELECT e.ename, e.job, e.sal, d.dname
        FROM emp e, dept d 
        WHERE e.deptno = d.deptno;

DECLARE     
    p_ename emp.ename%TYPE;
    p_job emp.job%TYPE;
    p_sal emp.sal%TYPE;
    p_dname dept.dname%TYPE;
    
    -- 커서 선언
    CURSOR emp_cursor IS
        SELECT e.ename, e.job, e.sal, d.dname
        FROM emp e, dept d 
        WHERE e.deptno = d.deptno;
BEGIN
    OPEN emp_cursor;
    DBMS_OUTPUT.PUT_LINE('이름    직급  급여  부서명');
    LOOP
        FETCH emp_cursor INTO p_ename, p_job, p_sal, p_dname;
        EXIT WHEN emp_cursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(p_ename || '   ' || p_job || ' '|| p_sal || '  ' || p_dname );
    END LOOP;
    CLOSE emp_cursor;
END;
/


-- 커서에 입력 파라미터가 있는 커서
DECLARE 
    CURSOR student_cursor(score exam_01.total%TYPE) IS
        SELECT s.name, s.grade, e.total, d.dname
        FROM student s, department d, exam_01 e 
            WHERE s.deptno1 = d.deptno
                AND s.studno = e.studno
                AND e.total >= 90;
BEGIN
    DBMS_OUTPUT.PUT_LINE('      성적 우수자      ');
    DBMS_OUTPUT.PUT_LINE('  이름  학년  점수  학과명 ');
    
    FOR student_rec IN student_cursor(90) LOOP
        DBMS_OUTPUT.PUT_LINE('  ' || student_rec.name || '  ' || student_rec.grade
            || '    ' || student_rec.total || ' ' || student_rec.dname);
    END LOOP;    
END;
/






