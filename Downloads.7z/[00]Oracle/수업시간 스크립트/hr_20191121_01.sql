-- 2019년 11월 21일 목요일
-- 조인(Join)  =
-- 조인 조건에 동등연산자(=)를 사용하는 조인 -> 동등조인(Equi-Join)

SELECT * FROM dept;
SELECT * FROM emp;

SELECT * FROM emp, dept
WHERE emp.deptno = dept.deptno;

-- 두 개의 테이블을 조인
SELECT e.employee_id, e.first_name, e.last_name, e.hire_date,
    d.department_id, d.department_name
FROM employees e, departments d
WHERE e.department_id = d.department_id;
SELECT * FROM employees;
SELECT * FROM jobs;
-- 세 개의 테이블 조인
SELECT e.employee_id, e.first_name, e.last_name, e.hire_date,
    d.department_id, d.department_name, j.job_title
FROM employees e, departments d, jobs j
WHERE e.department_id = d.department_id
    AND e.job_id = j.job_id
    AND e.department_id = 110;


SELECT * FROM locations;
SELECT * FROM departments;

-- 네 개의 테이블 조인
SELECT e.employee_id, e.first_name, e.last_name, e.hire_date,
    d.department_id, d.department_name, j.job_title, l.city
FROM employees e, departments d, jobs j, locations l
WHERE e.department_id = d.department_id
    AND e.job_id = j.job_id
    AND d.location_id = l.location_id;

    
-- 조인 조건과 일반 조건을 제시하는 경우
-- emp 테이블에서 직급이 과장만 조회. 단, 이름, 직급, 급여, 부서명을 출력
SELECT e.ename 이름, e.job 직급, e.sal 급여, d.dname 부서명 
FROM emp e, dept d
WHERE e.deptno = d.deptno
    AND e.job = '과장';


--------------------------------------------------------------------------
-- 비동등조인(Non-Equi Join)
-- 조인조건에 동등 연산자가 아닌 대소 비교 연산자(> >=, <, <=)를  사용한 조인
-- guest 테이블에 마일리지(point) 점수를 통해서 gift 테이블의 어떤 상품을 받을 수 있는지 조회
-- guest 테이블과 gift 테이블을 조인에서 마일리지 점수에 따라서 받을 수 있는 상품을 조회
SELECT * FROM guest;
SELECT * FROM gift;

SELECT  gs.gname 고객명, gs.point 포인트, gf.gname 사은폼
FROM guest gs, gift gf
WHERE gs.point >= gf.g_start
    AND gs.point <= gf.g_end;

SELECT  gs.gname 고객명, gs.point 포인트, gf.gname 사은폼
FROM guest gs, gift gf
WHERE gs.point BETWEEN gf.g_start AND gf.g_end;

-- 자기 직급에서 최저 연봉을 받는 직원을 조회. 
-- 단, 이름, 급여, 부서명, 직급, 직급하한급여, 직급상한급여
SELECT e.first_name 이름, e.salary 급여, d.department_name 부서명, 
    j.job_title 직급, j.min_salary 직급하한급여, j.max_salary 직급상한급여
FROM employees e, departments d, jobs j
WHERE e.department_id = d.department_id
    AND e.salary <= j.min_salary;



--------------------------------------------------------------------
-- Self Join
SELECT e.employee_id, e.first_name, e.manager_id, m.first_name
FROM employees e, employees m
WHERE e.manager_id = m.employee_id;


SELECT * FROM emp;
SELECT e.ename 이름, e.job 직급, em.ename 관리자
FROM emp e, emp em
WHERE e.mgr = em.empno;

-----------------------------------------------------------------------
-- 외부조인(Outer Join)
-- 조인에 참여한 두 테이블에서 같은 값을 가지는 행들만 결과로 조회되는데 - 내부
-- 한쪽에 값이 없더라도 조인에 참여 시켜서 조회결과에 포함시키는 조인
SELECT e.ename, e.mgr, em.empno FROM emp e, emp em
WHERE e.mgr = em.empno(+);

SELECT e.ename, e.mgr, em.empno FROM emp e, emp em
WHERE e.mgr = em.empno;


--##########################################################################
-- 표준 SQL -> ANSI, ISO
-- 크로스 조인(CROSS JOIN)
SELECT e.ename, e.job, e.deptno, d.loc
FROM emp e, dept d
WHERE e.deptno = d.deptno;

SELECT e.ename, e.job, e.deptno, d.loc
FROM emp e CROSS JOIN dept d;

-- 안시 내부조인(Ansi Inner Join)
-- 기존 안시조인
SELECT e.employee_id, e.first_name, e.last_name, e.hire_date,
d.department_id, d.department_name
FROM employees e, departments d
WHERE e.department_id = d.department_id;

-- 안시 내부조인
SELECT e.employee_id, e.first_name, e.last_name, e.hire_date,
d.department_id, d.department_name
FROM employees e INNER JOIN departments d;


--##############################################################################
-- 서브쿼리
-- 단일행 다중컬럼을 반환하는 서브쿼리
-- 컴퓨터공학과 교수 중에서 급여가 제일 많은 교수의 정보를 조회
-- 단, 이름, 급여, 입사일, 부서명
SELECT *  FROM professor;
SELECT * FROM department;

-- 컴퓨터공학과 교수 중에서 급여가 제일 많은 교수
SELECT profno, name, pay 
FROM professor 
WHERE deptno = 101;
ORDER BY pay DESC;

SELECT deptno, MAX(pay) FROM professor 
WHERE deptno = 101
GROUP BY deptno;

SELECT p.name, p.pay, p.hiredate, d.dname
FROM professor p, department d
WHERE p.deptno = d.deptno
    AND (p.deptno, p.pay) IN(SELECT deptno, MAX(pay) FROM professor
                        WHERE deptno = 101 
                        GROUP BY deptno);

-- 다중행 다중컬럼을 반환하는 서브쿼리
-- 부서별 최고 급여를 받는 사원의 정보조회
-- 단, 사번, 이름, 직급, 급여, 부서명
SELECT empno 사번, ename 이름, job 직급, sal 급여, dname 부서명
FROM emp e, dept d
WHERE e.deptno = d.deptno
    AND(e.deptno, e.sal) IN(SELECT deptno, MAX(sal) FROM emp GROUP BY deptno);


-- 연관성 있는 서브쿼리
-- 메인 쿼리와 서브쿼리가 조인이 되는 서브쿼리
-- 자신이  속한 부서의 급여 평균보다 급여를 많이 받는 사원의 정보를 출력
-- 단, 이름, 급여, 부서명 
select * from emp;
SELECT e.ename, e.sal, d.dname
FROM emp e, dept d
WHERE e.deptno = d.deptno
    AND e.sal > (SELECT AVG(sal) FROM emp es
        WHERE e.deptno = es.deptno);

--- 스칼라 서브 쿼리(Scalar Sub Query)
--- SELECT 절에 기술되는 서브쿼리
-- 조인을 이용
SELECT ename 이름, e.hiredate 입사일, d.dname 부서명
FROM emp e, dept d
WHERE e.deptno = d.deptno;

-- 스칼라 서브쿼리 이용
SELECT ename 이름, e.hiredate 입사일, 
    (SELECT dname FROM dept d WHERE e.deptno = d.deptno) 부서명
FROM emp e;


-- 인라인 뷰(Inline View)
-- FROM 절에 기술되는 서브쿼리
-- 사원 테이블에서 평균 급여 이하를 받는 사원의 정보를 조회
-- 단, 사번, 이름, 급여, 부서명, 평균급여, 최저급여를 출력
SELECT ROWNUM no, empno 사번, ename 이름, sal 급여, 
    dname 부서명, es.min 최저급여, es.avg 평균급여
FROM emp e, dept d, 
    (SELECT MIN(sal) min, AVG(sal) avg FROM emp) es
WHERE e.deptno = d.deptno
    -- AND sal <= es.avg;
    AND sal BETWEEN es.min AND es.avg    
ORDER BY sal DESC;

-- 급여를 제일 적게 받는 사람 순위 1 ~ 5
SELECT e.*, d.dname
    FROM (SELECT ROWNUM no, es.*
            FROM (SELECT * FROM emp ORDER BY sal) es) e, dept d
WHERE e.deptno = d.deptno
    AND no >= 3 AND no <= 7;








