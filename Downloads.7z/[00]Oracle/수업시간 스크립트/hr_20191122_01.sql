-- 2019년 11월 22일 금요일  
--##########################################################
-- 데이터 조작어(DML, Data Manipulation Language) - 데이터 추가, 수정, 삭제   
CREATE TABLE member(
    no NUMBER,
    id VARCHAR2(15),
    password VARCHAR2(15),
    name VARCHAR2(5 CHAR),
    gender VARCHAR2(2 CHAR),
    email VARCHAR2(20),
    phone VARCHAR2(13));


INSERT INTO member VALUES(
  1, 'oracle', 'oracle1234', '홍길동', '남성', 'oracle@naver.com', '010-1234-5678');
INSERT INTO member VALUES(
  2, 'javagirl', 'javamania', '김하나', '여성', 'java@oracle.com', '010-4321-9876');
INSERT INTO member VALUES(
  3, 'database', 'mysql', '최고집', '남성', 'database@gmail.com', '010-1111-7777');

-- 테이블의 컬럼을 추가
SELECT * FROM member;
ALTER TABLE member
ADD (reg_date DATE);

UPDATE member SET reg_date=SYSDATE WHERE no=1;
UPDATE member SET reg_date=SYSDATE WHERE no=2;
UPDATE member SET reg_date=SYSDATE WHERE no=3;
commit;
SELECT * FROM member;

CREATE TABLE member01(
    id VARCHAR2(15),
    name VARCHAR2(5 CHAR),
    pass VARCHAR2(15),
    gender VARCHAR2(2 CHAR),
    phone VARCHAR2(13 CHAR),
    email VARCHAR2(20),
    reg_date DATE
);

SELECT * FROM member01;

-- member01 테이블에 데이터 추가
INSERT INTO member01 VALUES('midas', '마이더스', '12345678', '남성', 
    '041-1235-9654', 'midas@gmail.com', '2010-05-25');
INSERT INTO member01 VALUES('midas11', '왕호감', '1234', '남성', 
    NULL, 'midas11@naver.com', SYSDATE);  

INSERT INTO member01(id, name, gender, reg_date, email)
VALUES('member01', '어머나', '여성', SYSDATE, 'member01@daum.net');
commit;

DROP TABLE member01;
SELECT * FROM member01;

-- 데이터 수정하기
UPDATE member01
SET name='한국인', gender='여성', phone='010-5555-9999'
WHERE id='midas11';
commit;
SELECT * FROM member01;
SELECT * FROM member;

UPDATE member01
    SET (phone, email) = (SELECT phone, email
                        FROM member
                        WHERE id='database')
WHERE id='midas11';
commit;

-- 데이터 삭제하기
DELETE FROM member01
WHERE id = 'midas11';
commit;



--#####################################################################
-- 테이블 생성과 변경
-- 테이블은 오라클 DB 객체이며 DB 객체를 생성하는 명령을 DDL(Data Definition Language)이라고 함
DROP TABLE char_table01;
CREATE TABLE char_table01 (
name1 CHAR(6),
name2 CHAR(6 CHAR),
name3 VARCHAR2(6),
name4 VARCHAR2(6 CHAR)
);

--- 문자 데이터
INSERT INTO char_table01 VALUES('ABC', '홍', 'ABC', '홍');
INSERT INTO char_table01 VALUES('ABC', '홍길', 'ABC', '홍길');
INSERT INTO char_table01 VALUES('ABC', '홍길동', 'ABC', '홍길동');
INSERT INTO char_table01 VALUES('ABC', '홍길동홍길동', 'ABC', '홍길동홍길동');
commit;
-- KO16MSWIN949
SELECT * FROM nls_database_parameters;
SELECT LENGTHB(name1) name1, LENGTHB(name2) name2,
LENGTHB(name3) name3, LENGTHB(name4) name4 FROM char_table01;


-- 숫자형 데이터
CREATE TABLE num_table01(
num1 NUMBER,
num2 NUMBER(7),
num3 NUMBER(7, 2),
num4 NUMBER(5),
num5 NUMBER(6, -1)
);
INSERT INTO num_table01 VALUES(12345.67, 12345.67, 123456.789, 12345.67, 12345.67);
commit;
SELECT * FROM num_table01;
SELECT * FROM nls_database_parameters;
SELECT * FROM nls_session_parameters;
-- 날자 데이터
ALTER SESSION SET NLS_DATE_FORMAT='YYYY-MM-DD HH24:MI:SS';
ALTER SESSION SET NLS_TIMESTAMP_FORMAT='YYYY-MM-DD HH24:MI:SS.FF';
ALTER SESSION SET NLS_TIMESTAMP_TZ_FORMAT='YYYY-MM-DD HH24:MI:SS.FF TZR';
CREATE TABLE date_table01(
date1 DATE,
date2 TIMESTAMP,
date3 TIMESTAMP WITH TIME ZONE
);
INSERT INTO date_table01 VALUES(SYSDATE, SYSDATE, SYSDATE);
INSERT INTO date_table01 VALUES(SYSDATE, SYSTIMESTAMP, SYSTIMESTAMP);
commit;
SELECT * FROM date_table01;


DESC emp;
SELECT constraint_name, constraint_type, table_name FROM user_constraints;
WHERE table_name='EMP';

-- NOT NULL 제약조건
CREATE TABLE null_table01(
    name VARCHAR2(5 CHAR) NOT NULL,
    age NUMBER(3) NOT NULL, 
    text VARCHAR2(50)
);
INSERT INTO null_table01 VALUES('홍길동', 25, '좋은친구');
INSERT INTO null_table01(name, age) VALUES('홍길동', 30);
INSERT INTO null_table01(name) VALUES('임꺽정');


-- 유일키 제약조건(Unique Constraint)
CREATE TABLE unique_table(
    id VARCHAR2(10) UNIQUE NOT NULL,
    name VARCHAR2(5 CHAR) NOT NULL,
    phone VARCHAR2(13) NOT NULL,
    email VARCHAR2(20) NOT NULL,
    text VARCHAR2(100), 
    CONSTRAINT unique_table_uk UNIQUE(phone, email)
); 


INSERT INTO unique_table(id, name, phone, email, text) VALUES('member', '강감찬',
    '010-2222-3333', 'test@naver.com', '유일키는 NULL을 비교 대상에서 제외시킨다.');
INSERT INTO unique_table(id, name, phone, email) VALUES('member1', '김유신',
    '010-2222-3333', 'test@naver.com');
INSERT INTO unique_table(id, name, phone, email) VALUES('member', '김유신',
    '011-2222-3333', 'test@naver.com');    


-- 기본키 제약조건(Primary Key Constraint)
-- 인라인 방식 기본키 지정
CREATE TABLE pri_table01(
    no NUMBER PRIMARY KEY,
    name VARCHAR2(5 CHAR) CONSTRAINT pri_table01_notnull NOT NULL,
    address VARCHAR2(80 CHAR)
);

SELECT * FROM  pri_table01;
SELECT constraint_name, constraint_type FROM user_constraints
WHERE table_name='PRI_TABLE01';

INSERT INTO pri_table01 VALUES(1, '홍길동', '서울 구로구 구로동');
INSERT INTO pri_table01(no, name) VALUES(1, '강감찬');
INSERT INTO pri_table01(name) VALUES('이순신');

-- 아웃라인 방식 기본키 지정
CREATE TABLE pri_table02(
   no NUMBER,
   name VARCHAR2(5 CHAR) NOT NULL,
   address VARCHAR2(80 CHAR),
   CONSTRAINT pri_table02_pk PRIMARY KEY(no)
);

INSERT INTO pri_table02 VALUES(1, '홍길동', '서울 구로구 구로동');
INSERT INTO pri_table02(no, name) VALUES(1, '강감찬');
INSERT INTO pri_table02(name) VALUES('이순신');

-- 테이블 생성 후에 제약조건 주기
CREATE TABLE pri_table03(
    no NUMBER,
    name VARCHAR2(5 CHAR) NOT NULL,
    address VARCHAR2(80 CHAR)
);

ALTER TABLE pri_table03
ADD CONSTRAINT pri_table03_pk PRIMARY KEY(no);

INSERT INTO pri_table03 VALUES(1, '홍길동', '서울 구로구 구로동');
INSERT INTO pri_table03(no, name) VALUES(1, '강감찬');
INSERT INTO pri_table03(name) VALUES('이순신');


-- 외래키 제약조건(Foreign Key Constraint)
-- 외부키라고도 하며 참조하고 있는 컬럼의 값 이외에 값은 저장되지 못하게하는 제약조건
CREATE TABLE dept01(
    deptno NUMBER,
    deptname VARCHAR2(10 CHAR) NOT NULL,
    location VARCHAR2(10 CHAR) NOT NULL,
    CONSTRAINT dept01_pk PRIMARY KEY(deptno)
);

INSERT INTO dept01 VALUES(1001, '관리부', '서울');
INSERT INTO dept01 VALUES(1002, '영업부', '대전');
INSERT INTO dept01 VALUES(1003, '전산부', '인천');
INSERT INTO dept01 VALUES(1004, '생산부', '충남');
COMMIT;

SELECT * FROM dept01;

-- 인라인 방식 외부키 설정
DROP TABLE emp01;
CREATE TABLE emp01(
    empno NUMBER PRIMARY KEY,
    name VARCHAR2(5 CHAR) NOT NULL,
    hiredate DATE NOT NULL,
    deptno NUMBER NOT NULL
        CONSTRAINT emp01_fk REFERENCES dept01(deptno)
);

CREATE TABLE emp02(
    empno NUMBER PRIMARY KEY,
    name VARCHAR2(5 CHAR) NOT NULL,
    hiredate DATE NOT NULL,
    deptno NUMBER NOT NULL,
    --CONSTRAINT emp02_pk PRIMARY KEY(empno),
    CONSTRAINT emp02_fk FOREIGN KEY(deptno) REFERENCES dept01(deptno)
);

INSERT INTO emp02 VALUES(1002, '홍길동', SYSDATE, 1008);
COMMIT;


CREATE TABLE emp03(
    empno NUMBER PRIMARY KEY,
    name VARCHAR2(5 CHAR) NOT NULL,
    hiredate DATE NOT NULL,
    deptno NUMBER NOT NULL
);

ALTER TABLE emp03
ADD CONSTRAINT emp03_fk FOREIGN KEY(deptno) REFERENCES dept01(deptno);
INSERT INTO emp03 VALUES(1003, '어머나', SYSDATE, 1003);
COMMIT;
SELECT * FROM emp03;


-- CHECK 제약조건
CREATE TABLE mem(
    id VARCHAR2(15) PRIMARY KEY,
    name VARCHAR2(5 CHAR) NOT NULL,
    gender VARCHAR2(2 CHAR) CHECK(gender IN('남성', '여성')),
    sal NUMBER NOT NULL CHECK(sal BETWEEN 200 AND 500)
);

INSERT INTO mem VALUES('hostman1', '임꺽정', '중성', 300);
INSERT INTO mem VALUES('hostman', '임꺽정', '남성', 300);
INSERT INTO mem VALUES('jsphost', '홍길동', NULL, 400); -- NULL이 문제없이 추가

CREATE TABLE mem01(
    id VARCHAR2(15) PRIMARY KEY,
    name VARCHAR2(5 CHAR) NOT NULL,
    gender VARCHAR2(2 CHAR) NOT NULL,
    sal NUMBER NOT NULL,
    CONSTRAINT mem_gender_ck CHECK(gender IN('남성', '여성')),
    CONSTRAINT mem_sal_ck CHECK(sal BETWEEN 200 AND 500)
);
INSERT INTO mem01 VALUES('hostman01', '이순신', '남성', 300);
INSERT INTO mem01 VALUES('jsphost01', '강감찬', NULL, 400); -- NOT NULL 오류
INSERT INTO mem01 VALUES('hostman01', '김유신', '남성', 600); -- 범위를 넘어서 오류

CREATE TABLE default_dept(
    deptno NUMBER,
    deptname VARCHAR2(10 CHAR) NOT NULL,
    location VARCHAR2(10 CHAR) DEFAULT '서울' NOT NULL,
    CONSTRAINT default_dept_pk PRIMARY KEY(deptno)
);
INSERT INTO default_dept VALUES(1005, '인사부', '대전'); 
INSERT INTO default_dept(deptno, deptname) VALUES(1006, '관리부');-- 기본 값이 입력됨
INSERT INTO default_dept VALUES(1007, '총무부', NULL); -- NOT NULL 오류


-- 제약조건 수정, 삭제  교안참고
-- 테이블 복사
-- 제약조건은 NOT NULL을 제외한 나머지는 복사되지 않음
CREATE TABLE mem05 AS SELECT * FROM mem01;
SELECT * FROM mem05;

--- 테이블 이름 변경
SELECT * FROM member;
SELECT * FROM members;

RENAME member TO members;

SELECT * FROM dept01;
SELECT * FROM emp01;
SELECT * FROM emp02;

DROP TABLE dept01 CASCADE CONSTRAINT;


SELECT CONSTRAINT_NAME, CONSTRAINT_TYPE,  SEARCH_CONDITION 
FROM user_constraints
WHERE table_name='EMP01';

