--- 2019년 11월 25일 월요일
--- 오라클 객체
--- 뷰(View), 시퀀스(Sequence), 인덱스(Index), 동의어(Synonym)

--##################################################################
--- 1. 뷰  : 테이블이나 다른 뷰를 이용해 생성
--- 데이터가 저장되는 것이 아니라 SQL 문 저장 

-- 뷰 생성
CREATE VIEW emp_view AS
SELECT empno, ename, job, hiredate, deptno FROM emp;


SELECT * FROM emp_view;

DESC user_views
SELECT * FROM user_views;
SELECT * FROM user_tables;
--CREATE VIEW emp_view AS
CREATE OR REPLACE VIEW emp_view AS
SELECT empno 사번, ename 이름, job 직급, birthday 생일, hiredate 입사일
FROM emp 
WHERE deptno IN(10, 30);

SELECT * FROM emp_view;

--- 조인을 이용한 뷰 생성
-- 여러 테이블을 조인해 생성하는 뷰를 복합뷰(Composite View)라 함
CREATE OR REPLACE VIEW emp_min_sal AS
SELECT e.ename 이름, e.job 직급, e.hiredate 입사일, e.sal 급여, d.dname 부서명
FROM emp e, dept d
WHERE e.deptno = d.deptno
    AND (e.job, e.sal) IN(SELECT job, MIN(sal) FROM emp
                            GROUP BY job
                            HAVING MAX(sal) NOT IN(SELECT MAX(sal) FROM emp))
ORDER BY e.sal DESC;
SELECT * FROM emp_min_sal;

DESC emp_min_sal;

-- 생성 뷰의 내용 보기
DESC user_views;
SELECT view_name, text_length, text FROM user_views;
SELECT * FROM user_tables;


-- 오라클 데이터베이스 객체의 삭제 DROP
DROP VIEW emp_view;


--#####################################################################
-- 시퀀스(SEQUENCE)
-- 일정한 규칙에 따라서 증가하거나 감소하는 일련번호를 생성해 주는 객체
-- 시퀀스 생성하기
-- 시퀀스 테스트용 테이블 생성
DROP TABLE seq_member;
CREATE TABLE seq_member(
    no NUMBER PRIMARY KEY,
    name VARCHAR2(5 CHAR) NOT NULL,
    age NUMBER(3) NOT NULL
);

DROP SEQUENCE seq_member_no;
CREATE SEQUENCE seq_member_no
    --START WITH 1
    INCREMENT BY 1
    MAXVALUE 10000;

-- 시퀀스 객체에 사용할 수 있는 의사컬럼
-- 시퀀스 객체의 현재 번호
SELECT seq_member_no.CURRVAL FROM dual;

-- 시퀀스 개체의 다음 번호
SELECT seq_member_no.NEXTVAL FROM dual;

INSERT INTO seq_member VALUES(seq_member_no.CURRVAL, '홍길동', 25);
INSERT INTO seq_member VALUES(seq_member_no.NEXTVAL, '어머마', 22);
INSERT INTO seq_member VALUES(seq_member_no.NEXTVAL, '김철수', 32);
commit;    
SELECT * FROM seq_member;

-- 시퀀스 수정
ALTER SEQUENCE seq_member_no
    MAXVALUE 5000
    CACHE 5;


-- 시퀀스 삭제
DROP SEQUENCE seq_member_no;


-- ###########################################################
-- 인덱스(INDEX), 색인
-- 인덱스 : 데이터를 빠르게 검색하기 위해서 색인을 만들어 놓고 색인을 검색해서 빠르게 찾음

-- 인덱스 생성
-- 단일 컬럼으로 인덱스를 생성 -> 단일 인덱스, 
-- 두 개 이상의 컬럼으로 인덱스를 생성 -> 복합 인덱스
-- 인덱스 테스트용 테이블 생성
CREATE TABLE index_emp(
    empno NUMBER,
    ename VARCHAR2(5 CHAR),
    hiredate DATE,
    sal NUMBER,
    deptno NUMBER
);

-- index_emp 데이터 추가에 사용할 시퀀스 생성
CREATE SEQUENCE seq_indexemp_empno
    MINVALUE 1
    START WITH 1;

-- index_emp 테이블에 데이터를 추가 emp 테이블에 25행의 데이터를 이용해
-- 10만번 추가
BEGIN
    FOR i in 1.. 100000 LOOP
        INSERT INTO index_emp SELECT seq_indexemp_empno.NEXTVAL, 
            ename, hiredate, sal, deptno FROM emp;
    END LOOP
    COMMIT;
END;
/

SELECT * FROM index_emp;
SELECT COUNT(*) FROM index_emp;

-- 검색에 사용할 데이터 추가
INSERT INTO index_emp 
VALUES(seq_indexemp_empno.NEXTVAL, '감사봉', '2011-12-01', 350, 40);

-- 이름이 감사봉인 사원 검색
SELECT * FROM index_emp WHERE ename = '감사봉';

-- index_emp 테이블에 ename 컬럼에 인덱스 생성
CREATE INDEX ind_indexemp_ename
ON index_emp(ename);


SELECT * FROM user_indexes
WHERE INDEX_NAME='IND_INDEXEMP_ENAME';
SELECT * FROM user_sequences;

-- HR 계정으로 접속해서 작업
-- hrtest 계정에 hr.members 테이블을 조회할 수 있는 권한 부여
GRANT SELECT ON members TO hrtest;

-- HR 계정으로 접속해서 작업
-- 비공개 동의어(SYNONYM) 생성
CREATE SYNONYM m01 FOR members;

-- HR 계정으로 접속해서 작업
-- 비공개 동의어 수정
CREATE OR REPLACE SYNONYM m for members;



--- HR 계정에서 test1 에게 members 테이블에 접근할 수 있는 권한 부여
GRANT SELECT, INSERT, UPDATE, DELETE ON members 
TO test1
WITH GRANT OPTION;

-- HR 계정으로 접속해 아래 테이블을 생성하고 데이터 추가
CREATE TABLE member(no NUMBER, name VARCHAR2(5 CHAR));

INSERT INTO member VALUES(1001, '오라클');
INSERT INTO member VALUES(1002, '어머나');
INSERT INTO member VALUES(1003, '홍길동');
commit;

-- HR 계정에서 TEST1 계정에게 MEMBER 테이블의 조회 권한을 부여
GRANT SELECT ON member TO test1;

-- HR 계정에세 TEST1 계정에 부여한 MEMBER 테이블 조회 권한을 회수
REVOKE SELECT ON member FROM test1;

SELECT * FROM user_tab_privs_made
WHERE grantee='TEST1';














































